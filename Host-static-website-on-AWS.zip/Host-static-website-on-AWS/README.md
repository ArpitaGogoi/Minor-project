# Host-static-website-on-AWS
A static website uses server-side rendering to serve pre-built HTML, CSS, and JavaScript files to a web browser.
Static sites enable you to decouple your content repository and front-end interface, giving you greater flexibility in how your content is served. Cost-efficiency is another reason companies migrate to a static site because static files are lightweight and often faster and cheaper to serve.


Preview Link:

http://static-website-minor-project.s3-website-us-east-1.amazonaws.com
